#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
	char *strOne = "This is the result from Lab08\n";
	char *strTwo = "CSIS 430: Online Lecture Video\n\n";

	for(int x=0; x<5; x++)
	{
		hello(strOne);
		hello(strTwo);
	}
	
	exit();
}